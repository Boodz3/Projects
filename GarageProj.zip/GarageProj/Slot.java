public class Slot {
    private float length;
    private float width;
    private Vehicle occupant;

    public Slot() {
        length = 0;
        width = 0;
        occupant = null;
    }
    
    public void setLength(float l){
        length = l;
    }
    public void setWidth(float w){
        width = w;
    }
    public float getLength(){return length;}
    public float getWidth(){return width;}
    public float getArea(){return length*width;}
    public void setDimention(float l, float w){
        length = l;
        width = w;
    }
    public void setOccupant(Vehicle v){
        occupant = v;
    }
    public Vehicle getOccupant(){
        return occupant;
    }
}
