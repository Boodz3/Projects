public class program {
    public static void main(String[] args) {
        GarageController c = new GarageController();
        GarageInterface gi = c.getInterface();
        gi.menu();
    }
}