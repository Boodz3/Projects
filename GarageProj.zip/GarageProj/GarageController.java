import java.util.Vector;

public class GarageController {
    // private Vehicle[] vehicles;
    private Vector<Vehicle> vehicles = new Vector<Vehicle>();
    private Garage garage = new Garage();
    private GarageInterface ginterface;
    
    private String vehicleInLine = "";

    private String adminPassword = "adminadmin";
    private boolean adminMode = false;



    public GarageController(){
        ginterface = new GarageInterface(this);
    }

    public Boolean setupGarage(int nSlot, int  configType, Slot [] s){
        if(adminMode){
        garage.setUpGarage(nSlot, configType, s);
        return true;
        }
        else{
            ginterface.unauthorized();
            return false;
        }
    }
    public void addGarageSlot(float l, float w){
        if(adminMode){
            garage.addSlot(l, w);
        }
        else{
            ginterface.unauthorized();
        }
    }

    public Boolean isFull() {
        return garage.getOccupiedSlots() == garage.getNumSlots();
    }

    public void parkin() {
        if (isFull()) {
            ginterface.showGarageFull();
        } else {
            while (!ginterface.showVehicleForm()) {
                ginterface.ShowInvalidInput();
            }
            Vehicle vinline = getVehicle(vehicleInLine);
            int vinlineSlot = assignSlot(vehicleInLine);
            if(vinlineSlot == -1){
                ginterface.showGarageFull();
            }else{
            vinline.setAssignedSlot(vinlineSlot);
            ginterface.showSlot(vinline.getAssignedSlot());
            //store current system time
            vinline.setArrivalTime(System.currentTimeMillis());
            }
        }
    }

    public void parkout(String id) {
        Vehicle v = getVehicle(id);
        garage.getSlots()[v.getAssignedSlot()].setOccupant(null);
        v.setAssignedSlot(-1);
        ginterface.showFee(calculateFee(v));

    }

    public Boolean addVehicle(String name, String id, int year, float len, float wid) {
        if (len < 0 || wid < 0) {
            return false;
        }
        vehicleInLine = id;
        if(getVehicle(id) != null){
            return true;
        }
        Vehicle v = new Vehicle(name, id, year, len, wid);
        vehicles.add(v);
        garage.setTotalVehicles(garage.getTotalVehicles() + 1);
        return true;
    }

    public int assignSlot(String id) {
        Vehicle v = getVehicle(id);
        if (garage.getConfig() == 1) {
            for (int i = 0; i < garage.getNumSlots(); i++) {
                if (garage.getSlots()[i].getOccupant() == null &&
                        garage.getSlots()[i].getLength() >= v.getLength() &&
                        garage.getSlots()[i].getWidth() >= v.getWidth()) {
                    return i;
                }
            }
        } else if (garage.getConfig() == 2) {
            // assigns the smallest slot that fits vechile
            int assigned = -1;
            for (int i = 0; i < garage.getNumSlots(); i++) {
                if (garage.getSlots()[i].getOccupant() == null) {
                    if (garage.getSlots()[i].getLength() >= v.getLength() &&
                            garage.getSlots()[i].getWidth() >= v.getWidth()) {
                        if (assigned == -1) {
                            assigned = i;
                        } else {
                            if (garage.getSlots()[i].getArea() < garage.getSlots()[assigned].getArea()) {
                                assigned = i;
                            }
                        }
                    }
                }
            }
            return assigned;
        }
        return -1;
    }

    public Vehicle getVehicle(String id) {
        for (int i = 0; i < vehicles.size(); i++) {
            if (vehicles.elementAt(i).getID().equals(id)) {
                return vehicles.elementAt(i);
            }
        }
        return null;
    }


    public boolean authorize(String pw) {
        if (pw.equals(adminPassword)) {
            adminMode = true;
            ginterface.correctPassword();
            return true;
        } else {
            ginterface.wrongPassword();
            return false;
        }
    }

    public void adminLogout() {
        adminMode = false;
    }

    public int calculateFee(Vehicle v){
        float depTime = System.currentTimeMillis();
        float arrTime = v.getArrivalTime();
        float parkingTime = depTime - arrTime;
        //round up
        int arrivalTimeHours = (int) Math.ceil(parkingTime / (1000 * 60 * 60));
        int pricePerHour = 5;
        int fee = arrivalTimeHours * pricePerHour;

        garage.setTotalRevenue(garage.getTotalRevenue() + fee);
        return fee;
    }

    public GarageInterface getInterface() {
        return ginterface;
    }

    public Garage getGarage(){
        return garage;
    }

    public boolean isAuthorized() {
        return adminMode;
    }
}
