import java.util.Scanner;

public class GarageInterface {
    private Scanner sc;
    private GarageController garageController;

    public GarageInterface(GarageController gc) {
        sc = new Scanner(System.in);
        garageController = gc;
    }

    public void checkSpace() {
        if (garageController.isFull()) {
            System.out.println("Garage is full");
        } else {
            System.out.println("Garage is not full");
        }
    }

    public void showGarageFull() {
        System.out.println("Garage is full");
    }

    public void parkin() {
        garageController.parkin();
    }

    public boolean showVehicleForm() {
        String name, id;
        int modelYear;
        float length, width;
        System.out.println("Enter the vehicle's model name: ");
        name = sc.nextLine();
        System.out.println("Enter the vehicle's ID: ");
        id = sc.nextLine();
        System.out.println("Enter the vehicle's model year: ");
        modelYear = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the vehicle's length: ");
        length = sc.nextFloat();
        sc.nextLine();
        System.out.println("Enter the vehicle's width: ");
        width = sc.nextFloat();
        sc.nextLine();
        return garageController.addVehicle(name, id, modelYear, length, width);
    }

    public void ShowInvalidInput() {
        System.out.println("Input is invalid");
    }

    public void parkout() {
        System.out.println("Enter the vehicle's ID: ");
        String id;
        id = sc.nextLine();
        garageController.parkout(id);
    }

    public void showSlot(int num) {
        System.out.println("Slot " + num + " is your Assigned Slot Number");
    }

    public void ownerForm() {
        String pw;
        System.out.println("Enter Owner Password: ");
        pw = sc.nextLine();
        garageController.authorize(pw);
    }

    public void garageSetupForm() {
        if (garageController.isAuthorized()) {
            System.out.println("Enter the number of slots: ");
            int nslots;
            nslots = sc.nextInt();
            sc.nextLine();
            System.out.println("Enter the configuration method: ");
            System.out.println("1) First come first served");
            System.out.println("2) Best-fit");
            int ct = sc.nextInt();
            sc.nextLine();
            Slot slots[] = new Slot[nslots];
            System.out.println("Garage Slots size setup:");
            for (int i = 0; i < nslots; i++) {
                System.out.println("Enter the size of slot " + (i + 1));
                float l = sc.nextFloat();
                float w = sc.nextFloat();
                System.out.println(l + w);
                slots[i] = new Slot();
                slots[i].setDimention(l, w);
            }
            garageController.setupGarage(nslots, ct, slots);
            sc.nextLine();
        } else {
            unauthorized();
        }
    }

    public void menu() {
        int choice;
        do {
            System.out.println("1) Garage setup");
            System.out.println("2) Park in");
            System.out.println("3) Park out");
            System.out.println("4) Owner Form");
            System.out.println("5) log out");
            choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    garageSetupForm();
                    break;
                case 2:
                    parkin();
                    break;
                case 3:
                    parkout();
                    break;
                case 4:
                    ownerForm();
                    break;
                case 5:
                    logout();
                    break;
                default:
                    choice = -1;
                    break;
            }
        } while (choice != -1);
    }

    public void showFee(float fee) {
        System.out.println("Fee: " + fee);
    }

    public void logout() {
        garageController.adminLogout();
        System.out.println("Logged out");
    }

    public void wrongPassword() {
        System.out.println("Wrong Password");
    }

    public void correctPassword() {
        System.out.println("Correct Password.. Logged In");
    }

    public void unauthorized() {
        System.out.println("you are not authorized todo this action, please login first");
    }

    public void showTotalRevenue(int rev) {
        System.out.println("Total Revenue: " + rev);
    }
}
