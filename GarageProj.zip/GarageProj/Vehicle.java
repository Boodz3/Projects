public class Vehicle {
    // modelName, ID, modelYear, length, width attributes
    private String modelName;
    private String ID;
    private int assignedSlot;
    private int modelYear;
    private float length;
    private float width;
    private float arrivalTime;

    //CONSTRUCTOR
    public Vehicle(String modelName, String ID, int modelYear, float length, float width) {
        this.modelName = modelName;
        this.ID = ID;
        this.modelYear = modelYear;
        this.length = length;
        this.width = width;
        this.assignedSlot = -1;
    }

    //SETTERS AND GETTERS FOR attributes
    public String getModelName() {
        return modelName;
    }

    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public int getModelYear() {
        return modelYear;
    }

    public void setModelYear(int modelYear) {
        this.modelYear = modelYear;
    }

    public float getLength() {
        return length;
    }

    public void setLength(float length) {
        this.length = length;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }
    
    public int getAssignedSlot() {
        return assignedSlot;
    }

    public void setAssignedSlot(int assignedSlot) {
        this.assignedSlot = assignedSlot;
    }
    public void setArrivalTime(float arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public float getArrivalTime() {
        return arrivalTime;
    }
}